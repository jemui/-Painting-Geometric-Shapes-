Jeanette Mui, jemui@ucsc.edu

Assignment 1: Painting Geometric Shapes
Paint web application that draws simple geometric shapes made out of triangles.

Files submitted: 
circle.js
square.js
triangle.js
geometry.js
vertex.js
renderer.js
scene.js
input.js
main.js
drive.html
README